import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { LoginComponent } from './login/login.component';
import { ErrorComponent } from './error/error.component';
import { ListAccountsComponent } from './list-accounts/list-accounts.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { FooterSocialMediaComponent } from './footer-social-media/footer-social-media.component';
import { FooterCopyrightsComponent } from './footer-copyrights/footer-copyrights.component';
import { LogoutComponent } from './logout/logout.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AccountComponent } from './account/account.component';
import { RegisterComponent } from './register/register.component';
import { HttpInterceptorBasicAuthenticationService } from './service/http-interceptor-basic-authentication.service';

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    LoginComponent,
    ErrorComponent,
    ListAccountsComponent,
    HeaderComponent,
    FooterComponent,
    FooterSocialMediaComponent,
    FooterCopyrightsComponent,
    LogoutComponent,
    AccountComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorBasicAuthenticationService, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
