import { Component, OnInit } from '@angular/core';
import { Account } from '../model/Account';
import { AccountDataService } from '../service/account-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-accounts',
  templateUrl: './list-accounts.component.html',
  styleUrls: ['./list-accounts.component.css']
})
export class ListAccountsComponent implements OnInit {

  accounts: Account[];
  message: string;

  // Hardcoded Array Account Objects
  /*
  accounts = [
    new Account(1, '1111', 1000, 'Savings Account', 'My Savings A/C Note', false, new Date()),
    new Account(2, '2222', 2000, 'Current Account', 'My Current A/C Note', false, new Date()),
    new Account(3, '3333', 3000, 'PPF Account', 'My PPF A/C Note', false, new Date())
  ]
  */

  // Hardcoded Account Objects
  /*
  accounts = [
    {
      id: 1,
      accountNumber: 1111,
      balance: 1000,
      description: 'Savings Account',
      note: 'My Savings A/C Note',
      select: false,
      openingDate: '01/01/2000'
    },
    {
      id: 2,
      accountNumber: 2222,
      balance: 2000,
      description: 'Current Account',
      note: 'My Current A/C Note',
      select: false,
      openingDate: '01/01/2001'
    },
    {
      id: 3,
      accountNumber: 3333,
      balance: 3000,
      description: 'PPF Account',
      note: 'My PPF A/C Note',
      select: false,
      openingDate: '01/01/2002'
    }
  ]
  */

  // Hardcoded Account Object
  /*
  account = {
    id: 1,
    accountNumber: 123456789,
    balance: 2000,
    description: 'Savings Account',
    note: 'My Savings A/C Note',
    select: false,
    openingDate: '01/01/2004'
  }
  */

  constructor(private accountDataService: AccountDataService, private router: Router) { }

  ngOnInit(): void {
    this.refreshAccount();
  }

  refreshAccount() {
    this.accountDataService.retrieveAllAccounts('pushkar').subscribe(
      response => {
        console.log(response);
        this.accounts = response;
      }
    );
  }

  deleteAccount(id) {
    this.accountDataService.deleteAccount('pushkar', id).subscribe(
      response => {
        console.log(response);
        this.message = `Delete of Account ${id} Successful`;
        this.refreshAccount();
      }
    );
  }

  updateAccount(id) {
    this.router.navigate(['account', id]);
  }

  createAccount(){
    this.router.navigate(['account', -1]);
  }

}
