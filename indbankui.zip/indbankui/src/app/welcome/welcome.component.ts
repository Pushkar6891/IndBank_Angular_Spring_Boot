import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WelcomeDataService } from '../service/welcome-data.service';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  welcomeMessage = 'Welcome to'
  bankName = 'IndBank'
  name = ''
  welcomeMessageFromService : string;
  isErrorPresent : boolean = false;
  errorMessage : string;

  constructor(private route: ActivatedRoute, private welcomeDataService: WelcomeDataService) { }

  ngOnInit(): void {
    //console.log(this.route.snapshot.params['name'])
    this.name = this.route.snapshot.params['name']
  }

  getWelcomeMessage() {
    //  console.log(this.welcomeDataService.executeWelcomeService());
    this.welcomeDataService.executeWelcomeService().subscribe(
      response => this.handleSuccessfulResponse(response),
      error => this.handleErrorResponse(error)
    );
    //  console.log('get welcome message')
  }

  getWelcomeMessageWithParameter() {
    //  console.log(this.welcomeDataService.executeWelcomeService());
    this.welcomeDataService.executeWelcomeServiceWithPathVariable(this.name).subscribe(
      response => this.handleSuccessfulResponse(response),
      error => this.handleErrorResponse(error)
    );
    //  console.log('get welcome message')
  }

  handleSuccessfulResponse(response) {
    this.welcomeMessageFromService = response.message;
    //console.log(response.message);
  }

  handleErrorResponse(error){
    this.isErrorPresent = true;
    this.errorMessage = "Some Error has Occurred Please Contact pushkarchauhan91@gmail.com"
    this.welcomeMessageFromService = error;
  }
}
