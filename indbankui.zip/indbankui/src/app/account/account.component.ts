import { Component, OnInit } from '@angular/core';
import { AccountDataService } from '../service/account-data.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Account } from '../model/Account';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {

  id: number;
  account: Account;

  constructor(private route: ActivatedRoute, private accountDataService: AccountDataService, private router: Router) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    this.account = new Account(this.id, '123', 123, 'dummy desc', 'dummy note', false, new Date(),"+919826396465","pushkarchauhan91@gmail.com");
    if (this.id != -1) {
      this.accountDataService.retrieveAccount('pushkar', this.id).subscribe(data => {
        this.account = data;
      }
      );
    }

  }

  saveAccount() {
    if (this.id != -1) {
      this.accountDataService.createAccount('pushkar', this.account).subscribe(
        data => {
          console.log(data)
          this.router.navigate(['listAccounts'])
        }
      )
    } else {
      this.accountDataService.updateAccount('pushkar', this.id, this.account).subscribe(
        data => {
          console.log(data)
          this.router.navigate(['listAccounts'])
        }
      )
    }
  }

}
