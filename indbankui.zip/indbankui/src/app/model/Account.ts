export class Account {

    public id: number;
    public accountNumber: string;
    public balance: number;
    public description: string;
    public note: string;
    public selects: boolean;
    public openingDate: Date;
    public mobile: string;
    public email: string;

    constructor(
        id,
        accountNumber,
        balance,
        description,
        note,
        select,
        openingDate,
        mobile,
        email
    ) {

    }

    public getId() {
        return this.id;
    }

    public getAccountNumber() {
        return this.accountNumber;
    }

    public getBalance() {
        return this.balance;
    }

    public getNote() {
        return this.note;
    }

    public getSelects() {
        return this.selects;
    }

    public getOpeningDate() {
        return this.openingDate;
    }

    public getMobile(){
        return this.mobile;
    }

    public getEmail(){
        return this.email;
    }
}