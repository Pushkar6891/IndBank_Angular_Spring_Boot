import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RegisterDataService {

  constructor(
    private http: HttpClient
  ) { }

  register(register) {
    return this.http.post('http://localhost:8061/registration/register', register);
  }


}
