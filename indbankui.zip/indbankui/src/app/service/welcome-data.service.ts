import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class WelcomeDataService {

  constructor(
    private http: HttpClient
  ) { }

  executeWelcomeService() {
    return this.http.get('http://localhost:8061/welcome');
  }

  executeWelcomeServiceWithPathVariable(name) {
    return this.http.get(`http://localhost:8061/welcomePathVariable/${name}`);
  }

}
