import { TestBed } from '@angular/core/testing';

import { RouteGraudService } from './route-graud.service';

describe('RouteGraudService', () => {
  let service: RouteGraudService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RouteGraudService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
