import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Account } from '../model/Account';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccountDataService {

  constructor(
    private http: HttpClient
  ) { }

  retrieveAccount(username, id): Observable<any> {
    return this.http.get<Account>(`http://localhost:8061/users/${username}/account/${id}`)
  }

  retrieveAllAccounts(username) {
    return this.http.get<Account[]>(`http://localhost:8061/users/${username}/account`)
  }

  deleteAccount(username, id) {
    return this.http.delete(`http://localhost:8061/users/${username}/account/${id}`)
  }

  updateAccount(username, id, account) {
    return this.http.put(`http://localhost:8061/users/${username}/account/${id}`, account);
  }

  createAccount(username, account) {
    return this.http.post(`http://localhost:8061/users/${username}/account`, account);
  }
}
