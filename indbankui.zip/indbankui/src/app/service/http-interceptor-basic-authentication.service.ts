import { Injectable } from '@angular/core';
import { HttpHandler, HttpRequest, HttpInterceptor } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpInterceptorBasicAuthenticationService implements HttpInterceptor {

  constructor() { }

  intercept(request: HttpRequest<any>, next: HttpHandler) {
    let username = 'pushkar';
    let password = 'dummy';
    let basicAuthHeaderString = 'Basic ' + window.btoa(username + ':' + password);


    request = request.clone({
      setHeaders: {
        'Authorization': basicAuthHeaderString,
        'Access-Control-Allow-Origin': '*'
      }
    });


    return next.handle(request);
  }

}
