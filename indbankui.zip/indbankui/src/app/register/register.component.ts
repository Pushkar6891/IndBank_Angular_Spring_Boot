import { Component, OnInit } from '@angular/core';
import { Register } from '../model/Register';
import { RegisterDataService } from '../service/register-data.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  register: Register;
  message: string;
  showMessage: boolean = false;


  constructor(private route: ActivatedRoute, private registerDataService: RegisterDataService, private router: Router) { }

  ngOnInit(): void {
    this.register = new Register('pushkar', 'pass', 'confirmPass', '12345', 'push@gmail.com');
  }

  registerData() {
    this.registerDataService.register(this.register).subscribe(
      data => {
        console.log(data)
        this.message = this.register.getUsername() + ' User Successfully registered ';
        this.showMessage = true;
      }
    )
  }
}
