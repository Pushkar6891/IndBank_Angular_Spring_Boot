import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-social-media',
  templateUrl: './footer-social-media.component.html',
  styleUrls: ['./footer-social-media.component.css']
})
export class FooterSocialMediaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
